boxes package
=============

Subpackage boxes.generators
---------------------------

.. automodule:: boxes.generators
    :members:
    :undoc-members:
    :show-inheritance:

:doc:`generators`

Submodules
----------

boxes.Color module
------------------

.. automodule:: boxes.Color
    :members:
    :undoc-members:
    :show-inheritance:

boxes.edges module
------------------

.. automodule:: boxes.edges
    :members:
    :undoc-members:
    :show-inheritance:

boxes.formats module
--------------------

.. automodule:: boxes.formats
    :members:
    :undoc-members:
    :show-inheritance:

boxes.gears module
------------------

.. automodule:: boxes.gears
    :members:
    :undoc-members:
    :show-inheritance:

boxes.lids module
-----------------

.. automodule:: boxes.lids
    :members:
    :undoc-members:
    :show-inheritance:

boxes.mounts module
-------------------

.. automodule:: boxes.mounts
    :members:
    :undoc-members:
    :show-inheritance:

boxes.parts module
------------------

.. automodule:: boxes.parts
    :members:
    :undoc-members:
    :show-inheritance:

boxes.pulley module
-------------------

.. automodule:: boxes.pulley
    :members:
    :undoc-members:
    :show-inheritance:

boxes.robot module
------------------

.. automodule:: boxes.robot
    :members:
    :undoc-members:
    :show-inheritance:

boxes.servos module
-------------------

.. automodule:: boxes.servos
    :members:
    :undoc-members:
    :show-inheritance:

boxes.svgutil module
--------------------

.. automodule:: boxes.svgutil
    :members:
    :undoc-members:
    :show-inheritance:

boxes.vectors module
--------------------

.. automodule:: boxes.vectors
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: boxes
    :members:
    :undoc-members:
    :show-inheritance:
