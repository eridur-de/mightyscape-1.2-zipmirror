.. include:: ../../README.rst
   :end-before: Documentation
