.. boxes.py documentation master file, created by
   sphinx-quickstart on Sun Mar 27 12:04:59 2016.

Boxes.py
========

Create boxes and more with a laser cutter!

Contents:

.. toctree::
   :maxdepth: 1

   README
   faq
   install
   usermanual
   CONTRIBUTING.rst
   apidoc
   generators

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
