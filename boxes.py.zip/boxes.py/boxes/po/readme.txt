This directory contains the translation files.

boxes.py.pot file gets generated from the sources
and the actual translations are kept in Zanata:
https://translate.zanata.org/iteration/view/boxes.py/master

use

zanata-cli pull

to get the new translations and

zanata-cli push

to put the .pot file on the server
