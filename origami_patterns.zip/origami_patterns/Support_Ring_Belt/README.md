# Origami_Patterns_Support_Belt

Designed to be used with the [Origami Patterns Inkscape extension](https://github.com/evbernardes/Origami_Patterns).

3D Print this with TPU (or any other flexible material) and use together with the support rings.
